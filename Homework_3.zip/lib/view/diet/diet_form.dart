import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tracker_app2/providers/diet_provider.dart';
import 'package:tracker_app2/providers/recording_provider.dart';

class DietForm extends StatefulWidget {
  @override
  _DietFormState createState() => _DietFormState();
}

class _DietFormState extends State<DietForm> {
  final TextEditingController _foodNameController = TextEditingController();
  final TextEditingController _foodQuantityController = TextEditingController();

  bool _showDropdown = false;

  @override
  Widget build(BuildContext context) {
    final dietProvider = Provider.of<DietProvider>(context);

    return SizedBox(
      child: Form(
        child: Column(children: [
          if (_showDropdown)
            DropdownButtonFormField<String>(
              value: null,
              hint: const Text('Select a Food'),
              onChanged: (newValue) {
                // Handle selection if needed
              },
              items: dietProvider.dietRecords
                  .map<DropdownMenuItem<String>>((record) {
                return DropdownMenuItem<String>(
                  value: record.id.toString(),
                  child: Text(record.food),
                );
              }).toList(),
            ),
          TextFormField(
            decoration: const InputDecoration(labelText: "Enter Food Name"),
            controller: _foodNameController,
            onChanged: (_) {
              setState(() {
                _showDropdown = false;
              });
            },
          ),
          TextFormField(
            decoration: const InputDecoration(labelText: "Enter Food Quantity"),
            controller: _foodQuantityController,
          ),
          ElevatedButton(
            child: const Text("Record Diet"),
            onPressed: () async {
              // Call the method to record the diet
              await dietProvider.addDietRecord(
                _foodNameController.text,
                int.parse(_foodQuantityController.text),
              );
              // ignore: use_build_context_synchronously
              FocusScope.of(context).unfocus();

              // ignore: use_build_context_synchronously
              Provider.of<RecordingProvider>(context, listen: false)
                  .recordEvent('diet');

              setState(() {
                _showDropdown = true;
              });

              _foodNameController.clear();
              _foodQuantityController.clear();
            },
          ),
        ]),
      ),
    );
  }
}
