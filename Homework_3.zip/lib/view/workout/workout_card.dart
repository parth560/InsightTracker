// workout_card.dart

import 'package:flutter/material.dart';
import 'package:tracker_app2/collections/workout_isar.dart';
import 'package:provider/provider.dart';
import 'package:tracker_app2/providers/workout_provider.dart';

class WorkoutCard extends StatelessWidget {
  final WorkoutRecord record;

  const WorkoutCard({required this.record, Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text(record.exercise),
        subtitle: Text("Quantity: ${record.quantity}"),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: Icon(Icons.delete),
              onPressed: () async {
                final workoutProvider =
                    Provider.of<WorkoutProvider>(context, listen: false);
                await workoutProvider.deleteWorkoutRecord(record);
              },
            ),
            SizedBox(width: 8),
            Text(
              "${record.timestamp.day}/${record.timestamp.month}/${record.timestamp.year}",
            ),
          ],
        ),
        onTap: () {},
        onLongPress: () {},
      ),
    );
  }
}
