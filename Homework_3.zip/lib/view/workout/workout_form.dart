import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:tracker_app2/providers/recording_provider.dart';
import 'package:tracker_app2/providers/workout_provider.dart';

class WorkoutForm extends StatefulWidget {
  @override
  _WorkoutFormState createState() => _WorkoutFormState();
}

class _WorkoutFormState extends State<WorkoutForm> {
  final TextEditingController _quantityController = TextEditingController();

  String? _selectedExercise;
  final List<String> _exerciseList = [
    'Running',
    'Cycling',
    'Weightlifting',
    'Swimming',
    'Yoga',
    'Jumping Jacks',
    'Squats',
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      child: Form(
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: _selectedExercise,
              hint: const Text('Select Exercise'),
              onChanged: (newValue) {
                setState(() {
                  _selectedExercise = newValue;
                });
              },
              items: _exerciseList.map((exercise) {
                return DropdownMenuItem<String>(
                  value: exercise,
                  child: Text(exercise),
                );
              }).toList(),
            ),
            TextFormField(
              decoration: const InputDecoration(labelText: "Enter Quantity"),
              controller: _quantityController,
              keyboardType: TextInputType.number,
            ),
            ElevatedButton(
              child: const Text("Record Workout"),
              onPressed: () async {
                final workoutProvider =
                    Provider.of<WorkoutProvider>(context, listen: false);
                if (_selectedExercise != null) {
                  await workoutProvider.addWorkoutRecord(
                    _selectedExercise!,
                    int.parse(_quantityController.text),
                  );
                  // ignore: use_build_context_synchronously
                  FocusScope.of(context).unfocus();
                  // ignore: use_build_context_synchronously
                  Provider.of<RecordingProvider>(context, listen: false)
                      .recordEvent('workout');
                }
                _quantityController.clear();
                setState(() {
                  _selectedExercise = null;
                });
              },
            ),
          ],
        ),
      ),
    );
  }
}
