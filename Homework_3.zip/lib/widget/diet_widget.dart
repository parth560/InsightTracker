import 'package:flutter/material.dart';
import 'package:tracker_app2/view/diet/diet_page.dart';
import 'package:tracker_app2/widget/bottom_sheet.dart';

class DietWidget extends StatelessWidget {
  const DietWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Diet Recorder'),
          actions: [
            IconButton(
              onPressed: () {
                showModalBottomSheet(
                    context: context,
                    builder: (context) => const BottomSheetWidget());
              },
              icon: const Icon(Icons.add),
            ),
          ],
        ),
        body: const DietPage());
  }
}
