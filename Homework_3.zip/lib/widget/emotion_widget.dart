import 'package:flutter/material.dart';
import 'package:tracker_app2/view/emotion/emotion_page.dart';
import 'package:tracker_app2/widget/bottom_sheet.dart';

class EmotionWidget extends StatelessWidget {
  const EmotionWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Emotion Recorder'),
        actions: [
          IconButton(
            onPressed: () {
              showModalBottomSheet(
                  context: context,
                  builder: (context) => const BottomSheetWidget());
            },
            icon: const Icon(Icons.add),
          ),
        ],
      ),
      body: const EmotionPage(),
    );
  }
}
