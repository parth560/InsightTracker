import 'package:flutter/material.dart';
import 'package:tracker_app2/collections/emotion_isar.dart';
import 'package:tracker_app2/repositories/emotion_repo.dart';

class EmotionProvider extends ChangeNotifier {
  final EmotionRepository _repository;

  EmotionProvider(this._repository);

  List<EmotionRecord> _emotions = [];
  List<EmotionRecord> get emotions => _emotions;

  get selectedEmotion => null;

  // Set the selected emotion
  void setEmotion(EmotionRecord emotion) async {
    // Assuming you have a method in your repository to add an emotion
    await _repository.addEmotion(emotion);
    _emotions = await _repository.getEmotions();
    notifyListeners();
  }

  // Get all emotions from the Isar database
  Future<void> getEmotions() async {
    _emotions = await _repository.getEmotions();
    notifyListeners();
  }

  void deleteEmotion(EmotionRecord emotion) async {
    if (emotion.id != null) {
      await _repository.deleteEmotion(emotion.id!);
      _emotions.removeWhere((element) => element.id == emotion.id);
      notifyListeners();
    } else {
      print('Error: Emotion ID is null');
    }
  }
}
